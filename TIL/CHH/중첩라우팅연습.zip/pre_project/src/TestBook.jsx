import React from 'react'
import {  Route, Routes } from 'react-router-dom'
import TestBookDetail from './TestBookDetail'

const TestBook = () => {


  return (
    <div>
      <h2>아기 돼지 삼형제</h2>
      <Routes>
        <Route path="/:pageNumber" element={<TestBookDetail />} />
      </Routes>
    </div>
  )
}

export default TestBook;