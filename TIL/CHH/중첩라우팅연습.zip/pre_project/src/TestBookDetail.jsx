import React from "react";
import { useParams } from "react-router-dom";

const TestBook = () => {
  let { pageNumber } = useParams();

  return (
    <div>
      <h3>{pageNumber} 하이</h3>
    </div>
  );
};

export default TestBook;
